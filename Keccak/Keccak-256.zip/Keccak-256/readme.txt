Following Keccak VHDL coeds from "High-speed core design" in the Website "The Keccak sponge function family (http://keccak.noekeon.org/KeccakVHDL-2.0.zip)" are required for this implementation.

keccak.vhd
keccak_buffer.vhd
keccak_globals.vhd
keccak_round.vhd
keccak_round_constants_gen.vhd
